#include <iostream>
using namespace std;
int main(){
    string c = "Sanveer";
    string d = "Singh";
    string e = c+d;
    cout<<e;

}